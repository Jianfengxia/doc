/*
Navicat MySQL Data Transfer

Source Server         : ms
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : msdevops

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2017-02-10 14:18:52
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `hredo`
-- ----------------------------
DROP TABLE IF EXISTS `hredo`;
CREATE TABLE `hredo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `bid` bigint(25) NOT NULL,
  `etype` tinyint(2) NOT NULL COMMENT '1:ok,2:fail',
  `edate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of hredo
-- ----------------------------
INSERT INTO `hredo` VALUES ('3', '1700688574', '2', '2017-02-10 13:22:10');
INSERT INTO `hredo` VALUES ('4', '514606064', '2', '2017-02-10 13:18:17');
