package com.didispace.domain;
public class ReturnResult {
	public Integer statusCode;// required
	public Object sresult;
	public Integer getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}
	public Object getSresult() {
		return sresult;
	}
	public void setSresult(Object sresult) {
		this.sresult = sresult;
	}
	 
	 

}